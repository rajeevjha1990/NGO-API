<div class="sidebar">
  <h2>सबका विकास जयति</h2>
  <ul class="menu">
    <li><a href="<?= base_url(); ?>dashboard">🏠 Dashboard</a></li>
    <li>
        <a href="javascript:void(0)" class="accordion-btn">
                <i class="fas fa-database"></i> Master Data ▾
        </a>
        <ul class="submenu">
          <li><a href="<?= base_url(); ?>programs">📋 Programs</a></li>
        </ul>
        </li>
    <!-- <li><a href="<?= base_url(); ?>beneficiaries">👥 Beneficiaries</a></li> -->
    <li><a href="<?= base_url(); ?>volunteers">🤝 Volunteers</a></li>
    <!-- <li><a href="<?= base_url(); ?>groups">🧩 Groups</a></li> -->
    <li><a href="<?= base_url(); ?>auth/group_edit_requests">✏️ Group Edit Requests</a></li>
    <!-- <li><a href="<?= base_url(); ?>reports">📊 Reports</a></li> -->
    <!-- <li><a href="<?= base_url(); ?>notifications">🔔 Notifications</a></li> -->
  </ul>
</div>
